# 📱 AI Chat Android App

多模型 AI 聊天应用，打包成 Android App。

## 🚀 打包方法（三选一）

### 方法一：GitHub Actions 自动打包（推荐）

**无需电脑，手机上就能完成！**

1. 在手机浏览器打开 GitHub：https://github.com
2. 注册/登录账号
3. 新建仓库，名称填 `ai-chat-app`
4. 点击 "uploading an existing file"
5. 把 `chat-ai-app` 文件夹里的所有文件拖进去
6. 点击 "Commit changes"
7. 等待 2-3 分钟，进入仓库的 "Actions" 标签
8. 点击构建任务，完成后下载 APK

---

### 方法二：电脑上用 Android Studio

1. 下载安装 Android Studio：https://developer.android.com/studio
2. 打开 Android Studio → Open → 选择 `chat-ai-app` 文件夹
3. 等待 Gradle 同步完成
4. 点击 Build → Build Bundle(s) / APK(s) → Build APK(s)
5. 完成后在 `app/build/outputs/apk/debug/` 找到 APK

---

### 方法三：Termux 命令行打包

```bash
# 安装依赖
pkg install openjdk-17 gradle

# 进入项目目录
cd /sdcard/Documents/chat-ai-app

# 构建
gradle assembleDebug

# APK 在这里
ls app/build/outputs/apk/debug/
```

---

## 📲 安装 APK

打包完成后，把 APK 传到手机上：

1. 打开文件管理器
2. 找到 APK 文件
3. 点击安装
4. 如果提示"未知来源"，去设置里允许安装

---

## ✨ 功能特点

- 🎨 暗色主题，沉浸式体验
- 🔄 支持 5 家 AI（OpenAI/Claude/文心/讯飞/通义）
- 💾 聊天记录本地保存
- 📱 原生 Android 体验
- ⚡ 启动秒开

---

## 📁 项目结构

```
chat-ai-app/
├── app/
│   ├── src/main/
│   │   ├── AndroidManifest.xml
│   │   ├── java/com/aichat/webview/
│   │   │   └── MainActivity.java
│   │   ├── assets/
│   │   │   └── index.html
│   │   └── res/
│   ├── build.gradle
│   └── proguard-rules.pro
├── build.gradle
├── settings.gradle
└── .github/workflows/build.yml
```
